"""
TODO: rewrite carbon.py
"""
# CmdHelp("carbon").add_command(
#     "carbon", "<your text>", "Carbonize your text. (Fixed style)"
# ).add_command(
#     "krb", "<your text>", "Carbonize your text.(Random Style)"
# ).add_command(
#     "kargb", "<your text>", "Carbonize your text.(random style)"
# ).add_info(
#     "Carbonizer"
# ).add_warning(
#     "✅ Harmless Module."
# ).add()
